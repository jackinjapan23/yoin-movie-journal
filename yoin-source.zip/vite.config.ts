import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
// Relative asset paths let the build work both at a domain root and at
// GitHub Pages' /<repository>/ project path.
export default defineConfig({ base: './', plugins: [react()] })
