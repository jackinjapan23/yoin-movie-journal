create table public.found_reviews (
  id uuid primary key default gen_random_uuid(),
  film_id uuid not null references public.films(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (length(trim(title)) > 0),
  author text,
  source_name text,
  source_url text,
  content text not null check (length(trim(content)) > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint found_reviews_film_owner_unique unique (id, film_id, user_id)
);

create index found_reviews_film_created_idx on public.found_reviews(film_id, created_at desc);
create index found_reviews_user_created_idx on public.found_reviews(user_id, created_at desc);

create trigger found_reviews_set_updated_at before update on public.found_reviews
for each row execute function public.set_updated_at();

alter table public.found_reviews enable row level security;

create policy "users manage own found reviews" on public.found_reviews
  for all to authenticated
  using (
    (select auth.uid()) = user_id
    and exists (select 1 from public.films f where f.id = film_id and f.user_id = (select auth.uid()))
  )
  with check (
    (select auth.uid()) = user_id
    and exists (select 1 from public.films f where f.id = film_id and f.user_id = (select auth.uid()))
  );

grant select, insert, update, delete on public.found_reviews to authenticated;
