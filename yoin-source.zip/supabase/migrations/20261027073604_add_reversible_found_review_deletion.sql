alter table public.found_reviews
  add column deleted_at timestamptz;
