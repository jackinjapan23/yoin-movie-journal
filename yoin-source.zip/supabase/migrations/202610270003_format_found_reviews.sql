alter table public.found_reviews
  drop constraint found_reviews_content_check;

alter table public.found_reviews
  alter column content type jsonb
  using jsonb_build_object(
    'type', 'doc',
    'content', jsonb_build_array(
      jsonb_build_object(
        'type', 'paragraph',
        'content', jsonb_build_array(
          jsonb_build_object('type', 'text', 'text', content)
        )
      )
    )
  );

alter table public.found_reviews
  add column personal_notes text;
