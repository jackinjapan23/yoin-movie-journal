-- Yoin: private film journal, reviews, vocabulary and stable inline occurrences.
create extension if not exists pgcrypto;

create table public.films (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (length(trim(title)) > 0),
  original_title text,
  release_year integer check (release_year between 1888 and 2100),
  director text,
  genres text[] not null default '{}',
  poster_url text,
  rating numeric(3,1) check (rating between 0 and 10),
  date_watched date,
  status text not null default 'reviewed' check (status in ('planned','watching','reviewed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  film_id uuid not null unique references public.films(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  content jsonb not null default '{"type":"doc","content":[{"type":"paragraph"}]}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint reviews_film_owner_unique unique (film_id, user_id)
);

create table public.vocabulary (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  expression text not null check (length(trim(expression)) > 0),
  reading text not null default '',
  meaning text not null default '',
  notes text,
  learned boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.vocabulary_occurrences (
  id uuid primary key default gen_random_uuid(),
  vocabulary_id uuid not null references public.vocabulary(id) on delete cascade,
  review_id uuid not null references public.reviews(id) on delete cascade,
  occurrence_identifier text not null,
  created_at timestamptz not null default now(),
  constraint vocabulary_occurrences_review_identifier_unique unique (review_id, occurrence_identifier)
);

create index films_user_watched_idx on public.films(user_id, date_watched desc nulls last);
create index films_user_title_idx on public.films(user_id, title);
create index reviews_user_film_idx on public.reviews(user_id, film_id);
create index vocabulary_user_created_idx on public.vocabulary(user_id, created_at desc);
create index vocabulary_user_expression_idx on public.vocabulary(user_id, expression);
create index vocabulary_occurrences_review_idx on public.vocabulary_occurrences(review_id);
create index vocabulary_occurrences_vocabulary_idx on public.vocabulary_occurrences(vocabulary_id);

create function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger films_set_updated_at before update on public.films
for each row execute function public.set_updated_at();
create trigger reviews_set_updated_at before update on public.reviews
for each row execute function public.set_updated_at();
create trigger vocabulary_set_updated_at before update on public.vocabulary
for each row execute function public.set_updated_at();

alter table public.films enable row level security;
alter table public.reviews enable row level security;
alter table public.vocabulary enable row level security;
alter table public.vocabulary_occurrences enable row level security;

create policy "users manage own films" on public.films
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy "users manage own reviews" on public.reviews
  for all to authenticated
  using (
    (select auth.uid()) = user_id
    and exists (select 1 from public.films f where f.id = film_id and f.user_id = (select auth.uid()))
  )
  with check (
    (select auth.uid()) = user_id
    and exists (select 1 from public.films f where f.id = film_id and f.user_id = (select auth.uid()))
  );

create policy "users manage own vocabulary" on public.vocabulary
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy "users manage own vocabulary occurrences" on public.vocabulary_occurrences
  for all to authenticated
  using (
    exists (select 1 from public.vocabulary v where v.id = vocabulary_id and v.user_id = (select auth.uid()))
    and exists (select 1 from public.reviews r where r.id = review_id and r.user_id = (select auth.uid()))
  )
  with check (
    exists (select 1 from public.vocabulary v where v.id = vocabulary_id and v.user_id = (select auth.uid()))
    and exists (select 1 from public.reviews r where r.id = review_id and r.user_id = (select auth.uid()))
  );

grant usage on schema public to authenticated;
grant select, insert, update, delete on public.films, public.reviews, public.vocabulary, public.vocabulary_occurrences to authenticated;
